@extends('layouts.app')

@section('content')
    <div class="container product_index pt-3 pb-5 z-index-1">
        {{-- 1 --}}
        @if (session()->has('error_catalog'))
            <div class="error-dialog">
                <span class="error-message">{{ session('error_catalog') }}</span>
            </div>
        @endif
        <script>
            @if (session()->has('error_catalog'))
                var dialog = document.querySelector('.error-dialog');
                dialog.classList.add('show');
                const displayTime = 5000; // 5 секунд
                // Через заданный интервал времени скрываем диалоговое окно
                setTimeout(() => {
                    dialog.classList.remove('show');
                }, displayTime);
            @endif
        </script>

        {{-- 2 --}}
        @if (session()->has('cart_success'))
            <div class="alert-success">
                <span class="error-message">{{ session('cart_success') }}</span>
            </div>
        @endif
        <script>
            @if (session()->has('cart_success'))
                var dialog = document.querySelector('.alert-success');
                dialog.classList.add('show');
                const displayTime = 5000; // 5 секунд
                // Через заданный интервал времени скрываем диалоговое окно
                setTimeout(() => {
                    dialog.classList.remove('show');
                }, displayTime);
            @endif
        </script>

        {{-- 3 --}}
        @if (session()->has('error_booking'))
            <div class="error-dialog">
                <span class="error-message">{{ session('error_booking') }}</span>
            </div>
        @endif
        <script>
            @if (session()->has('error_booking'))
                var dialog = document.querySelector('.error-dialog');
                dialog.classList.add('show');
                const displayTime = 5000; // 5 секунд
                // Через заданный интервал времени скрываем диалоговое окно
                setTimeout(() => {
                    dialog.classList.remove('show');
                }, displayTime);
            @endif
        </script>

        {{-- 4 --}}
        @if (session()->has('booking_success'))
            <div class="alert-success">
                <span class="error-message">{{ session('booking_success') }}</span>
            </div>
        @endif
        <script>
            @if (session()->has('booking_success'))
                var dialog = document.querySelector('.alert-success');
                dialog.classList.add('show');
                const displayTime = 5000; // 5 секунд
                // Через заданный интервал времени скрываем диалоговое окно
                setTimeout(() => {
                    dialog.classList.remove('show');
                }, displayTime);
            @endif
        </script>

        <div class="row">
            <div class="col-md-7">
                <img src="/img/{{ $product->image }}" alt="{{ $product->name }}" class="img-thumbnail w-100">
            </div>
            <div class="col-md-5 red-bg">
                <div class="poduct__right">
                    <div class="row">
                        <div class="col-md-7">
                            <h2 class="text-36px text-white mt-5">{{ $product->name }}</h2>
                        </div>
                        <div class="col-md-5">
                            <p class="rent_or_buy">{{ $product->rent_or_buy }}</p>
                        </div>
                    </div>
                    @if ($product->rent_or_buy == 'Аренда')
                        <p class="product__price text-25px text-red mt-4 mb-5">{{ $product->price }} руб./сутки.</p>
                    @else
                        <p class="product__price text-25px text-red mt-4 mb-5">{{ $product->price }} руб.</p>
                    @endif

                    <p class="product__size mt-4 text-25px text-white">Размер: <strong
                            class="ms-2">{{ $product->size }}</strong></p>
                    <div class="mt-5 w-100 text-red">
                        @guest
                            @if (Route::has('login'))
                                <a href="{{ url('/login') }}" class="login__booking">Авторизоваться</a>
                            @endif
                        @else
                            @if ($product->rent_or_buy == 'Аренда')
                                <form action="/bookings" method="post" class="d-flex flex-column pe-5 mt-5">
                                    @csrf
                                    <input type="hidden" name="product_id" value="{{ $product->id }}">

                                    <label for="date" class="text-white">Дата бронирования:</label>
                                    <input type="date" name="date" id="date" required value="{{ date('Y-m-d') }}"
                                        min="{{ now()->format('Y-m-d') }}">

                                    <script>
                                        // Получаем занятые даты из базы данных
                                        var occupiedDates = {!! json_encode($occupiedDates) !!}; // Замените $occupiedDates на фактический список занятых дат

                                        // Обработчик изменения значения инпута
                                        document.getElementById("date").addEventListener("change", function() {
                                            var selectedDate = this.value;
                                            var isDateOccupied = occupiedDates.includes(selectedDate);

                                            // Проверяем, выбрана ли занятая дата
                                            if (isDateOccupied) {
                                                alert("Эта дата уже занята. Выберите другую дату.");
                                                this.value = ""; // Сбрасываем выбранную дату
                                            }
                                        });
                                    </script>


                                    @if ($user->phone == null)
                                        <div class="form-group row">
                                            <label for="phone"
                                                class="col-form-label text-md-right text-white">{{ __('Номер телефона:') }}</label>
                                            <div class="">
                                                <input id="phone" type="tel"
                                                    class="form-control @error('phone') is-invalid @enderror" name="phone"
                                                    value="{{ old('phone') }}" required autocomplete="phone" autofocus>
                                                @error('phone')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                    @endif

                                    <button type="submit" class="btn__in_cart mt-3">Забронировать</button>
                                </form>
                            @else
                                <form action="{{ route('cart.add', $product->id) }}" method="POST"
                                    class="d-flex flex-column pe-5">
                                    @csrf
                                    <button type="submit" class="btn__in_cart mt-3">В корзину</button>
                                </form>
                            @endif
                        @endguest
                    </div>
                    <p class="text-25px mt-5 text-white">Описание:<br>{{ $product->description }}</p>
                </div>
            </div>
        </div>
    </div>
    <div class="index__catalog_items mt-5 mb-5">
        <div class="container">
            <div class="row">
                @if ($products->isEmpty())
                    <h2 class="text-start ms-5 mb-3 text-36px index__catalog_title w-90"><strong>Наши новинки</strong></h2>
                    <div class="alert alert-danger m-0" role="alert">
                        <h2 class="m-0 p-0">Каталог пуст.</h2>
                    </div>
                @else
                    <h2 class="text-start ms-5 mb-5 text-36px index__catalog_title"><strong>Наши новинки</strong></h2>
                    <div class="d-flex justify-content-between flex-mobile-column ">
                        @foreach ($products as $product)
                            <div class="product mobile-product">
                                <a href="{{ route('product', $product->id) }}"
                                    class="text-black none-underline product_link p-relative h-100">
                                    <p class="catalog__rent_or_buy">{{ $product->rent_or_buy }}</p>
                                    <img src="/img/{{ $product->image }}" alt="{{ $product->name }}" class="h-100">
                                    <h3 class="mt-3 text-white text-25px w-250px text-center">{{ $product->name }}</h3>
                                    <p class="price text-25px w-100 text-center bg-light"><strong>{{ $product->price }}
                                            руб.</strong>
                                    </p>
                                </a>
                            </div>
                        @endforeach
                    </div>
                    <a class="w-100 text-center mt-5 text-black text-black_link" href="{{ url('/catalog') }}">Перейти к
                        каталогу</a>
                @endif
            </div>
        </div>
    </div>
@endsection
