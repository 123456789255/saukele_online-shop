@extends('layouts.app')

@section('content')
    <div class="container h-100vh align-center d-flex justify-content-center">
        <div class="d-flex justify-content-center"><h1>У вас нет доступа</h1></div>
    </div>
@endsection