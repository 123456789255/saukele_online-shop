@extends('layouts.admin')

@section('content')
    <div class="container">
        <h1>Редактировать товар</h1>

        <form method="post" action="{{ route('admin.updateProduct', $product->id) }}" enctype="multipart/form-data">
            @csrf
            @method('PUT')

            <div class="form-group">
                <label for="name">Название товара</label>
                <input type="text" class="form-control" id="name" name="name" value="{{ $product->name }}">
            </div>

            <div class="form-group">
                <label for="description">Описание товара</label>
                <textarea class="form-control" id="description" name="description" rows="5">{{ $product->description }}</textarea>
            </div>

            <div class="form-group">
                <label for="price">Цена товара</label>
                <input type="number" class="form-control" id="price" name="price" value="{{ $product->price }}">
            </div>

            <div class="form-group">
                <label for="gender">Пол</label>
                <select name="gender" class="form-control form-category" id="gender">
                    <option value="{{ $product->gender }}">{{ $product->gender }}</option>
                    @if ($product->gender == 'Женский')
                        <option value="Мужской">Мужской</option>
                        <option value="Унисекс">Унисекс</option>
                    @elseif($product->gender == 'Мужской')
                        <option value="Женский">Женский</option>
                        <option value="Унисекс">Унисекс</option>
                    @elseif($product->gender == 'Унисекс')
                        <option value="Мужской">Мужской</option>
                        <option value="Женский">Женский</option>
                    @endif
                </select>
            </div>

            <div class="form-group">
                <label for="category">Категория</label>
                <select class="form-control" id="category" name="category" required>
                    @foreach ($category as $cat)
                        <option value="{{ $cat->id }}"
                            {{ $cat->id == request()->query('category') ? 'selected' : '' }}>
                            {{ $cat->name_category }}</option>
                    @endforeach
                </select>
            </div>

            <div class="form-group">
                <label for="category">Подкатегория</label>
                <select class="form-control" id="subcategory" name="subcategory" required>
                    @foreach ($subcategories as $sub)
                        {{-- @if ($sub->category_id == $category->id) --}}
                        <option value="{{ $sub->id }}"
                            {{ $sub->id == request()->query('subcategory') ? 'selected' : '' }}>
                            {{ $sub->name }}</option>
                        {{-- @endif --}}
                    @endforeach
                </select>
            </div>

            <div class="form-group">
                <label for="rent_or_buy">Покупка или аренда</label>
                <select name="rent_or_buy" class="form-control form-category" id="rent_or_buy">
                    <option value="{{ $product->rent_or_buy }}">{{ $product->rent_or_buy }}</option>
                    @if ($product->rent_or_buy == 'Покупка')
                        <option value="Аренда">Аренда</option>
                    @elseif($product->rent_or_buy == 'Аренда')
                        <option value="Покупка">Покупка</option>
                    @endif
                </select>
            </div>

            <div class="form-group">
                <label for="quantity">Колличество товара на складе</label>
                <input type="number" class="form-control" id="quantity" name="quantity" value="{{ $product->quantity }}">
            </div>

            <div class="form-group">
                <label for="size">Размер</label>
                <input type="text" class="form-control" id="size" name="size" value="{{ $product->size }}">
            </div>

            <div class="form-group mt-3">
                <label for="image">Изображение товара</label>
                <input type="file" name="image" id="image" class="form-control-file" accept="image/*">
            </div>

            <button type="submit" class="btn btn-primary">Сохранить</button>
        </form>
    </div>
@endsection
