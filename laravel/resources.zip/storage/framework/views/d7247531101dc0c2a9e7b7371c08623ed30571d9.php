<?php $__env->startSection('content'); ?>
    <div class="auth__login">
        <div class="container">
            <div class="d-flex justify-content-center">
                <div class="col-md-8 mt-5 mb-5 border login_registration__panel">
                    <div class="row">
                        <div class="col-md-6 p-5">
                            <h1><strong>Вход</strong></h1>
                            <form method="POST" action="<?php echo e(route('login')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="row mb-3 mt-3">
                                    <label for="login"
                                        class="col-md-2 col-form-label text-md-start"><?php echo e(__('Логин')); ?></label>

                                    <div class="col-md-10">
                                        <input id="login" type="login"
                                            class="form-control <?php $__errorArgs = ['login'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="login"
                                            value="<?php echo e(old('login')); ?>" required autocomplete="login" autofocus>

                                        <?php $__errorArgs = ['login'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <label for="password"
                                        class="col-md-2 col-form-label text-md-start"><?php echo e(__('Пароль')); ?></label>

                                    <div class="col-md-10">
                                        <input id="password" type="password"
                                            class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password"
                                            required autocomplete="current-password">

                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-md-6 w-100 d-flex">
                                        <div class="form-check col-md-5">
                                            <input class="form-check-input" type="checkbox" name="remember" id="remember"
                                                <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                            <label class="form-check-label" for="remember">
                                                <?php echo e(__('Запомнить меня')); ?>

                                            </label>
                                        </div>
                                        <div class="password_reset col-md-6 ms-auto d-flex justify-content-end">
                                            <?php if(Route::has('password.request')): ?>
                                                <a class="btn btn-link text-end p-0 text-red forgot_password"
                                                    href="<?php echo e(route('password.request')); ?>">
                                                    <?php echo e(__('Забыли пароль?')); ?>

                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="row mb-0">
                                    <button type="submit" class="btn btn-saukele">
                                        <?php echo e(__('Войти')); ?>

                                    </button>
                                </div>
                            </form>
                        </div>
                        <div class="col-md-6 red-bg p-5 align-center d-flex flex-column justify-content-center">
                            <h2 class="text-white"><strong>Еще не зарегистрировался?</strong></h2>
                            <a href="<?php echo e(url('/register')); ?>"
                                class="btn__catalog_in_cart btn__auth btn btn-outline-light btn-register text-30px text-white w-100">Зарегистрироваться</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/o/otau2ru/public_html/laravel/resources/views/auth/login.blade.php ENDPATH**/ ?>