<?php echo e($slot); ?>

<?php /**PATH C:\OpenServer\domains\localhost-saukele\laravel\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>