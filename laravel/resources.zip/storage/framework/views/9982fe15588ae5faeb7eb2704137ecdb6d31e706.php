<?php $__env->startSection('content'); ?>
    <div class="container catalog mb-5 pt-5 z-index-1">
        
        <?php if(session()->has('error_catalog')): ?>
            <div class="error-dialog">
                <span class="error-message"><?php echo e(session('error_catalog')); ?></span>
            </div>
        <?php endif; ?>
        <script>
            <?php if(session()->has('error_catalog')): ?>
                var dialog = document.querySelector('.error-dialog');
                dialog.classList.add('show');
                const displayTime = 5000; // 5 секунд
                // Через заданный интервал времени скрываем диалоговое окно
                setTimeout(() => {
                    dialog.classList.remove('show');
                }, displayTime);
            <?php endif; ?>
        </script>

        
        <?php if(session()->has('cart_success')): ?>
            <div class="alert-success">
                <span class="error-message"><?php echo e(session('cart_success')); ?></span>
            </div>
        <?php endif; ?>
        <script>
            <?php if(session()->has('cart_success')): ?>
                var dialog = document.querySelector('.alert-success');
                dialog.classList.add('show');
                const displayTime = 5000; // 5 секунд
                // Через заданный интервал времени скрываем диалоговое окно
                setTimeout(() => {
                    dialog.classList.remove('show');
                }, displayTime);
            <?php endif; ?>
        </script>
        <h1 class="text-36px ms-5 mt-5">Каталог товаров</h1>
        <div class="row">
            <div class="col-md-2 left">
                <button class="btn__catalog_in_cart btn btn-primary catalog__mobile__filter d-md-none" type="button" data-bs-toggle="offcanvas"
                    data-bs-target="#offcanvasWithBackdrop" aria-controls="offcanvasWithBackdrop">Фильтр</button>

                <div class="offcanvas offcanvas-start" tabindex="-1" id="offcanvasWithBackdrop"
                    aria-labelledby="offcanvasWithBackdropLabel">
                    <div class="offcanvas-header">
                        <h2 class="offcanvas-title" id="offcanvasWithBackdropLabel">Фильтр</h2>
                        <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas"
                            aria-label="Close"></button>
                    </div>
                    <div class="offcanvas-body">
                        <form action="<?php echo e(route('catalog')); ?>" method="GET">
                            <div class="form-group mb-3">
                                <label for="gender mb-2">Пол:</label>
                                <select name="gender" class="form-control form-category pointer" id="gender">
                                    <option value="" <?php echo e(request()->input('gender') == '' ? 'selected' : ''); ?>>Выбор
                                    </option>
                                    <option value="Мужской" <?php echo e(request()->input('gender') == 'Мужской' ? 'selected' : ''); ?>>
                                        Мужской</option>
                                    <option value="Женский" <?php echo e(request()->input('gender') == 'Женский' ? 'selected' : ''); ?>>
                                        Женский</option>
                                    <option value="Унисекс" <?php echo e(request()->input('gender') == 'Унисекс' ? 'selected' : ''); ?>>
                                        Унисекс</option>
                                </select>
                            </div>
                            <div class="form-group mb-3">
                                <label for="rent_or_buy mb-2">Выберите метод<br>покупкa или арендa:</label>
                                <select name="rent_or_buy" class="form-control form-category pointer" id="rent_or_buy">
                                    <option value="" <?php echo e(request()->input('rent_or_buy') == '' ? 'selected' : ''); ?>>Выбор
                                    </option>
                                    <option value="Покупка"
                                        <?php echo e(request()->input('rent_or_buy') == 'Покупка' ? 'selected' : ''); ?>>Покупка</option>
                                    <option value="Аренда" <?php echo e(request()->input('rent_or_buy') == 'Аренда' ? 'selected' : ''); ?>>
                                        Аренда</option>
                                </select>
                            </div>
                            <div class="form-group mb-3">
                                <label for="category mb-2">Категория:</label>
                                <select name="category" class="form-control form-category pointer" id="category">
                                    <option value="">Все категории</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>" data-gender="<?php echo e($category->id); ?>"
                                            <?php echo e(request()->input('category') == $category->id ? 'selected' : ''); ?>>
                                            <?php echo e($category->name_category); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group mb-3">
                                <label for="category mb-2">Подкатегория:</label>
                                <select name="subcategory" class="form-control form-category pointer" id="subcategory">
                                    <option value="">Все подкатегории</option>
                                    <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($subcategory->id); ?>" data-gender="<?php echo e($subcategory->category_id); ?>"
                                            <?php echo e(request()->input('subcategory') == $subcategory->id ? 'selected' : ''); ?>>
                                            <?php echo e($subcategory->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="d-flex flex-column mb-3">
                                <label>Сортировка:</label>
                                <div class="ms-2 form-check">
                                    <input class="form-check-input pointer" type="radio" name="sort_by" id="sort_by_name"
                                        value="name" <?php echo e(request()->input('sort_by') == 'name' ? 'checked' : ''); ?>>
                                    <label class="form-check-label" for="sort_by_name">
                                        По наименованию
                                    </label>
                                </div>
                                <div class="ms-2 form-check">
                                    <input class="form-check-input pointer" type="radio" name="sort_by" id="sort_by_price"
                                        value="price" <?php echo e(request()->input('sort_by') == 'price' ? 'checked' : ''); ?>>
                                    <label class="form-check-label" for="sort_by_price">
                                        По цене
                                    </label>
                                </div>
                                <div class="ms-2 form-check">
                                    <input class="form-check-input pointer" type="radio" name="sort_by"
                                        id="sort_by_created_at" value="created_at"
                                        <?php echo e(request()->input('sort_by') == 'created_at' ? 'checked' : ''); ?>>
                                    <label class="form-check-label" for="sort_by_created_at">
                                        По новизне
                                    </label>
                                </div>
                                <label>Сортировка по:</label>
                                <div class="ms-2 form-check">
                                    <input class="form-check-input pointer" type="radio" name="sort_direction"
                                        id="sort_direction_asc" value="asc"
                                        <?php echo e(request()->input('sort_direction') == 'asc' ? 'checked' : ''); ?>>
                                    <label class="form-check-label" for="sort_direction_asc">
                                        По возрастанию
                                    </label>
                                </div>
                                <div class="ms-2 form-check">
                                    <input class="form-check-input pointer" type="radio" name="sort_direction"
                                        id="sort_direction_desc" value="desc"
                                        <?php echo e(request()->input('sort_direction') == 'desc' ? 'checked' : ''); ?>>
                                    <label class="form-check-label" for="sort_direction_desc">
                                        По убыванию
                                    </label>
                                </div>
                            </div>
                            <button type="submit" class="btn__catalog_in_cart btn btn-primary">Применить</button>
                        </form>
                    </div>
                </div>
                <div class="filters d-none-mobile">
                    <form action="<?php echo e(route('catalog')); ?>" method="GET">
                        <div class="form-group mb-3">
                            <label for="gender mb-2">Пол:</label>
                            <select name="gender" class="form-control form-category pointer" id="gender">
                                <option value="" <?php echo e(request()->input('gender') == '' ? 'selected' : ''); ?>>Выбор
                                </option>
                                <option value="Мужской" <?php echo e(request()->input('gender') == 'Мужской' ? 'selected' : ''); ?>>
                                    Мужской</option>
                                <option value="Женский" <?php echo e(request()->input('gender') == 'Женский' ? 'selected' : ''); ?>>
                                    Женский</option>
                                <option value="Унисекс" <?php echo e(request()->input('gender') == 'Унисекс' ? 'selected' : ''); ?>>
                                    Унисекс</option>
                            </select>
                        </div>
                        <div class="form-group mb-3">
                            <label for="rent_or_buy mb-2">Выберите метод<br>покупкa или арендa:</label>
                            <select name="rent_or_buy" class="form-control form-category pointer" id="rent_or_buy">
                                <option value="" <?php echo e(request()->input('rent_or_buy') == '' ? 'selected' : ''); ?>>Выбор
                                </option>
                                <option value="Покупка"
                                    <?php echo e(request()->input('rent_or_buy') == 'Покупка' ? 'selected' : ''); ?>>Покупка</option>
                                <option value="Аренда" <?php echo e(request()->input('rent_or_buy') == 'Аренда' ? 'selected' : ''); ?>>
                                    Аренда</option>
                            </select>
                        </div>
                        <div class="form-group mb-3">
                            <label for="category mb-2">Категория:</label>
                            <select name="category" class="form-control form-category pointer" id="category">
                                <option value="">Все категории</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>" data-gender="<?php echo e($category->id); ?>"
                                        <?php echo e(request()->input('category') == $category->id ? 'selected' : ''); ?>>
                                        <?php echo e($category->name_category); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group mb-3">
                            <label for="category mb-2">Подкатегория:</label>
                            <select name="subcategory" class="form-control form-category pointer" id="subcategory">
                                <option value="">Все подкатегории</option>
                                <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($subcategory->id); ?>" data-gender="<?php echo e($subcategory->category_id); ?>"
                                        <?php echo e(request()->input('subcategory') == $subcategory->id ? 'selected' : ''); ?>>
                                        <?php echo e($subcategory->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="d-flex flex-column mb-3">
                            <label>Сортировка:</label>
                            <div class="ms-2 form-check">
                                <input class="form-check-input pointer" type="radio" name="sort_by" id="sort_by_name"
                                    value="name" <?php echo e(request()->input('sort_by') == 'name' ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="sort_by_name">
                                    По наименованию
                                </label>
                            </div>
                            <div class="ms-2 form-check">
                                <input class="form-check-input pointer" type="radio" name="sort_by" id="sort_by_price"
                                    value="price" <?php echo e(request()->input('sort_by') == 'price' ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="sort_by_price">
                                    По цене
                                </label>
                            </div>
                            <div class="ms-2 form-check">
                                <input class="form-check-input pointer" type="radio" name="sort_by"
                                    id="sort_by_created_at" value="created_at"
                                    <?php echo e(request()->input('sort_by') == 'created_at' ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="sort_by_created_at">
                                    По новизне
                                </label>
                            </div>
                            <label>Сортировка по:</label>
                            <div class="ms-2 form-check">
                                <input class="form-check-input pointer" type="radio" name="sort_direction"
                                    id="sort_direction_asc" value="asc"
                                    <?php echo e(request()->input('sort_direction') == 'asc' ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="sort_direction_asc">
                                    По возрастанию
                                </label>
                            </div>
                            <div class="ms-2 form-check">
                                <input class="form-check-input pointer" type="radio" name="sort_direction"
                                    id="sort_direction_desc" value="desc"
                                    <?php echo e(request()->input('sort_direction') == 'desc' ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="sort_direction_desc">
                                    По убыванию
                                </label>
                            </div>
                        </div>
                        <button type="submit" class="btn__catalog_in_cart btn btn-primary">Применить</button>
                    </form>
                    <script>
                        // Получаем элементы селекторов
                        var genderSelect = document.getElementById('category');
                        var categorySelect = document.getElementById('subcategory');

                        // Слушаем изменения выбора пола
                        genderSelect.addEventListener('change', function() {
                            var selectedGender = genderSelect.value;

                            // Фильтруем категории на основе выбранного пола
                            for (var i = 0; i < categorySelect.options.length; i++) {
                                var option = categorySelect.options[i];
                                var categoryGender = option.getAttribute('data-gender');

                                if (selectedGender === '' || categoryGender === selectedGender) {
                                    option.style.display = 'block';
                                } else {
                                    option.style.display = 'none';
                                }
                            }
                        });

                        // Инициализируем фильтрацию категорий на основе текущего выбора пола
                        genderSelect.dispatchEvent(new Event('change'));
                    </script>
                </div>
            </div>
            <div class="col-md-10 right">
                <div class="products">
                    <?php if($products->isEmpty()): ?>
                        <div class="alert alert-danger w-100 m-0" role="alert">
                            <h2 class="m-0 p-0">Каталог пуст.</h2>
                        </div>
                    <?php else: ?>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($product->rent_or_buy == 'Аренда'): ?>
                                <?php if($product->quantity == '0'): ?>
                                    <div class="product flex-column product_quantity_0">
                                        <a href="<?php echo e(route('product', $product->id)); ?>"
                                            class="text-black none-underline product_link p-relative h-100"
                                            onclick="return false">
                                            <p class="catalog__rent_or_buy quantity_null">Нет в наличии</p>
                                            <img src="/img/<?php echo e($product->image); ?>" alt="<?php echo e($product->name); ?>"
                                                class="w-100 h-100">
                                            <h3 class="mt-3 text-red text-center"><strong><?php echo e($product->name); ?></strong>
                                            </h3>
                                            <p class="price w-100 text-center text-25px m-0 p-0"><?php echo e($product->price); ?>

                                                руб./сутки.</p>
                                            <button
                                                class="btn__catalog_in_cart btn btn-primary w-100 mt-3 text-25px ">Нет в наличии</button>
                                        </a>
                                    </div>
                                <?php else: ?>
                                    <div class="product flex-column">
                                        <a href="<?php echo e(route('product', $product->id)); ?>"
                                            class="text-black none-underline product_link p-relative h-100">
                                            <p class="catalog__rent_or_buy"><?php echo e($product->rent_or_buy); ?></p>
                                            <img src="/img/<?php echo e($product->image); ?>" alt="<?php echo e($product->name); ?>"
                                                class="w-100 h-100">
                                            <h3 class="mt-3 text-red text-center"><strong><?php echo e($product->name); ?></strong>
                                            </h3>
                                            <p class="price w-100 text-center text-25px m-0 p-0"><?php echo e($product->price); ?>

                                                руб./сутки.</p>
                                            <button
                                                class="btn__catalog_in_cart btn btn-primary w-100 mt-3 text-25px ">Подробнее</button>
                                        </a>
                                    </div>
                                <?php endif; ?>
                            <?php else: ?>
                                <?php if($product->quantity == '0'): ?>
                                    <div class="product flex-column product_quantity_0">
                                        <a href="<?php echo e(route('product', $product->id)); ?>"
                                            class="text-black none-underline product_link p-relative h-100"
                                            onclick="return false">
                                            <p class="catalog__rent_or_buy quantity_null">Нет в наличии</p>
                                            <img src="/img/<?php echo e($product->image); ?>" alt="<?php echo e($product->name); ?>"
                                                class="w-100 h-100">
                                            <h3 class="mt-3 text-red text-center"><strong><?php echo e($product->name); ?></strong>
                                            </h3>
                                            <p class="price w-100 text-center text-25px m-0 p-0"><?php echo e($product->price); ?>

                                                руб.
                                            </p>
                                            <form action="<?php echo e(route('cart.add', ['productId' => $product->id])); ?>"
                                                method="POST" class="w-100">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit"
                                                    class="btn__catalog_in_cart btn btn-primary w-100 mt-3 text-25px ">
                                                    Нет в наличии
                                                </button>
                                            </form>
                                        </a>
                                    </div>
                                <?php else: ?>
                                    <div class="product flex-column">
                                        <a href="<?php echo e(route('product', $product->id)); ?>"
                                            class="text-black none-underline product_link p-relative h-100">
                                            <p class="catalog__rent_or_buy"><?php echo e($product->rent_or_buy); ?></p>
                                            <img src="/img/<?php echo e($product->image); ?>" alt="<?php echo e($product->name); ?>"
                                                class="w-100 h-100">
                                            <h3 class="mt-3 text-red text-center"><strong><?php echo e($product->name); ?></strong>
                                            </h3>
                                            <p class="price w-100 text-center text-25px m-0 p-0"><?php echo e($product->price); ?>

                                                руб.
                                            </p>
                                            <form action="<?php echo e(route('cart.add', ['productId' => $product->id])); ?>"
                                                method="POST" class="w-100">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit"
                                                    class="btn__catalog_in_cart btn btn-primary w-100 mt-3 text-25px ">
                                                    Добавить в корзину
                                                </button>
                                            </form>
                                        </a>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\localhost-saukele\laravel\resources\views/catalog.blade.php ENDPATH**/ ?>