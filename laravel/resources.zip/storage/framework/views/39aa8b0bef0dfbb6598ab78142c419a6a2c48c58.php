<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">



<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e($title ?? 'Saukele'); ?></title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>

    <link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet">
    <link rel="shortcut icon" href="/img/radius-logo.svg" type="image/x-icon">
</head>

<body id="body">
    <div id="app" class="bg-white app">
        <div class="container p-0 header" id="header">
            <nav class="navbar navbar-expand-md navbar-light bg-white">
                <div class="w-100 flex-column">
                    <div class="d-flex w-100 align-center justify-content-around">
                        <div class="phone-div d-flex align-center justify-content-center">
                            <div class="phone-text text-center">
                                <a href="tel:+79088058925" class="text-black decoration-none">+7(962)047-39-00</a>
                                <a href="tel:+79088058925" class="text-black">Обратная связь</a>
                            </div>
                        </div>
                        <div class="img-toggler d-flex justify-content-around">
                            <a class="d-none phone" href="tel:+79088058925"><img src="/img/phone.svg"
                                    alt="phone"></a>
                            <a class="navbar-brand me-0 p-3" href="<?php echo e(url('/')); ?>">
                                <img class="logo" src="/img/logo.svg" alt="Logo">
                            </a>
                            <div class="hamb">
                                <div class="hamb__field" id="hamb">
                                    <span class="bar"></span>
                                    <span class="bar"></span>
                                    <span class="bar"></span>
                                </div>
                            </div>
                        </div>
                        <div class="collapse navbar-collapse top_collapse d-none-mobile" id="navbarSupportedContent">
                            <!-- Right Side Of Navbar -->
                            <div class="navbar-nav gap-3px">
                                <div class="nav-item">
                                    <a class="nav-link p-0" href="https://vk.com/saukele_omsk">
                                        <img class="vk w-53px" src="/img/vk.svg" alt="">
                                    </a>
                                </div>
                                <div class="nav-item">
                                    <a class="nav-link p-0" href="/cart">
                                        <img class="busket w-53px" src="/img/busket.svg" alt="">
                                    </a>
                                </div>
                                <!-- Authentication Links -->
                                <?php if(auth()->guard()->guest()): ?>
                                    <?php if(Route::has('login')): ?>
                                        <div class="nav-item like_at_login align-center d-flex">
                                            <a class="nav-link btn person-btn h-100 p-0" href="<?php echo e(route('login')); ?>"><img
                                                    class="auth w-54px" src="/img/person.svg" alt="<?php echo e(__('Login')); ?>"></a>
                                        </div>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <div class="nav-item dropdown align-center d-flex">
                                        <a class="btn person-btn p-0" id="person_btn">
                                            <img class="w-54px" src="/img/person.svg" alt="logo">
                                        </a>
                                        <div class="dropdown-menu" id="person_btn__dropdown">
                                            <?php if(Auth::user()->role == 2): ?>
                                                <a class="dropdown-item" href="/admin">Админка</a>
                                            <?php endif; ?>
                                            <a class="dropdown-item" href="/profile">Профиль</a>
                                            <a class="dropdown-item" href="/orders">Заказы</a>
                                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                                onclick="event.preventDefault();
                                                    document.getElementById('logout-form').submit();">Выход</a>

                                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                                class="d-none">
                                                <?php echo csrf_field(); ?>
                                            </form>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <ul class="menu justify-content-around" id="menu">
                        <li class="top_collapse justify-content-center d-none-desktop ul_person align-center"
                            id="navbarSupportedContent">
                            <?php if(auth()->guard()->guest()): ?>
                                <?php if(Route::has('login')): ?>
                                    <a class="nav-link p-0" href="https://vk.com/saukele_omsk">
                                        <img class="vk" src="/img/vk.svg" alt="">
                                    </a>
                                    <a class="nav-link  p-0" href="/cart">
                                        <img class="busket" src="/img/busket.svg" alt="">
                                    </a>
                                    <a class="nav-link btn person-btn h-100" href="<?php echo e(route('login')); ?>"><img
                                            class="auth" src="/img/person.svg" alt="<?php echo e(__('Login')); ?>"></a>
                                <?php endif; ?>
                            <?php elseif(Auth::user()->role == 2): ?>
                                <a class="nav-link" href="<?php echo e(url('/admin')); ?>">
                                    <img class="vk" src="/img/admin.svg" alt="">
                                </a>
                                <a class="nav-link" href="/cart">
                                    <img class="busket" src="/img/busket.svg" alt="">
                                </a>
                                <a href="<?php echo e(url('/orders')); ?>"><img src="/img/order.svg" alt=""></a>
                                <a class="dropdown-item" href="/profile"><img class="vk" src="/img/person.svg"
                                        alt=""></a>
                            <?php else: ?>
                                <a class="nav-link p-0" href="https://vk.com/saukele_omsk">
                                    <img class="vk" src="/img/vk.svg" alt="">
                                </a>
                                <a class="nav-link p-0" href="/cart">
                                    <img class="busket" src="/img/busket.svg" alt="">
                                </a>
                                <a href="<?php echo e(url('/orders')); ?>"><img src="/img/order.svg" alt=""></a>
                                <a class="dropdown-item" href="/profile"><img class="vk" src="/img/person.svg"
                                        alt=""></a>
                            <?php endif; ?>
                        </li>
                        <li class="active text-15px p-0">
                            <a class="nav-link text-black text-black_link mobile-text-black"
                                href="<?php echo e(url('/admin/orders')); ?>">Заказы</a>
                        </li>
                        <li class="text-15px p-0">
                            <a class="nav-link text-black text-black_link mobile-text-black"
                                href="<?php echo e(url('/admin/products')); ?>">Товары</a>
                        </li>
                        <li class="text-15px p-0">
                            <a class="nav-link text-white text-white_link mobile-text-black"
                                href="<?php echo e(url('/admin/category')); ?>">Категории</a>
                        </li>
                        <li class="text-15px p-0">
                            <a class="nav-link text-white text-white_link mobile-text-black"
                                href="<?php echo e(url('/admin/users')); ?>">Пользователи</a>

                        </li>

                    </ul>
                </div>
            </nav>
            <div class="popup blure" id="popup"></div>
        </div>

        <main class="z-index-1">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        <footer>
            <div class="container footer z-index-1 p-relative">
                <div class="d-none-mobile d-flex justify-content-around footer-partners">
                    <div class="d-flex justify-content-center">
                        <a class="partner1" href="https://vk.com/kazahi_omska">
                            <img src="/img/omby-kazaktar-mini.svg" width="210px" height="113px" alt="Спонсор">
                        </a>
                    </div>
                    <div class="justify-content-center mb-4 logo-d-none-mobile">
                        <a href="http://www.saukele.ru">
                            <img src="/img/logo.svg" alt="Лого" class="logo">
                        </a>
                    </div>
                    <div class="d-flex justify-content-around mobile_w-100 partner2-div">
                        <a class="d-none d-none-mobile w-mobile partner1-mobile" href="https://vk.com/kazahi_omska">
                            <img src="/img/omby-kazaktar-mini.svg" alt="Спонсор">
                        </a>
                        <a class="w-mobile partner2" href="https://vk.com/kazahi_omska">
                            <img src="/img/KO-mini.svg" width="210px" height="113px" alt="Спонсор">
                        </a>
                    </div>
                </div>
                <div class="footer-menu d-flex flex-wrap justify-content-around">
                    <div class="desctop mobile d-flex flex-wrap justify-content-around w-25">
                        <div class="d-flex flex-column">
                            <a class=" text text-black decoration-none text1rem text-black_link"
                                href="/">Главная</a>
                            <a class="mt-3 text text-black decoration-none text1rem text-black_link"
                                href="/catalog">Каталог</a>
                        </div>
                        <div class="d-flex flex-column">
                            <a class=" text text-black decoration-none text1rem text-black_link" href="/#about">О
                                нас</a>
                            <a class="mt-3 text text-black decoration-none text1rem text-black_link"
                                href="/#contacts">Контакты</a>
                        </div>
                        <div class="d-flex flex-column">
                            <a class=" text text-black decoration-none text1rem white-text text-black_link mobile-text-white_link"
                                href="/cart">Корзина</a>
                            <a class="mt-3 text text-black decoration-none text1rem white-text text-black_link mobile-text-white_link"
                                href="/orders">Заказы</a>
                        </div>
                    </div>
                    <div class="desctop mobile d-flex flex-wrap justify-content-around w-25 mt-3_mobile">
                        <div class="d-flex flex-column">
                            <a class=" text text-white decoration-none text1rem black-text text-white_link mobile-text-black_link"
                                href="tel:+79088058925">+7(962)047-39-00</a>
                            <a class="mt-3 text text-white decoration-none text1rem black-text text-white_link mobile-text-black_link"
                                href="mailto:kuho007@mail.ru?subject=Вопрос с сайта Saukele-Omsk.ru&body=Здравствуйте, ">kuho007@mail.ru</a>
                        </div>
                        <div class="d-flex flex-column">
                            <a class=" text text-white decoration-none text1rem text-white_link"
                                href="https://yandex.ru/maps/?um=constructor%3A008028625d0b227fc446a2cac6528f4ba88129d7f470e99485874cb0a81eb245&source=constructorLink">Ул.Ленина
                                38
                                оф.401</a>
                            <a class="mt-3 text text-white decoration-none text1rem text-white_link"
                                href="https://vk.com/saukele_omsk">Вконтакте</a>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    </div>
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous">
    </script>
    <script src="<?php echo e(asset('/js/script.js')); ?>"></script>
    
</body>

</html><?php /**PATH /home/o/otau2ru/public_html/laravel/resources/views/layouts/admin.blade.php ENDPATH**/ ?>