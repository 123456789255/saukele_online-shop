<?php $__env->startSection('content'); ?>
    <div class="container product_index pt-3 pb-5 z-index-1">
        
        <?php if(session()->has('error_catalog')): ?>
            <div class="error-dialog">
                <span class="error-message"><?php echo e(session('error_catalog')); ?></span>
            </div>
        <?php endif; ?>
        <script>
            <?php if(session()->has('error_catalog')): ?>
                var dialog = document.querySelector('.error-dialog');
                dialog.classList.add('show');
                const displayTime = 5000; // 5 секунд
                // Через заданный интервал времени скрываем диалоговое окно
                setTimeout(() => {
                    dialog.classList.remove('show');
                }, displayTime);
            <?php endif; ?>
        </script>

        
        <?php if(session()->has('cart_success')): ?>
            <div class="alert-success">
                <span class="error-message"><?php echo e(session('cart_success')); ?></span>
            </div>
        <?php endif; ?>
        <script>
            <?php if(session()->has('cart_success')): ?>
                var dialog = document.querySelector('.alert-success');
                dialog.classList.add('show');
                const displayTime = 5000; // 5 секунд
                // Через заданный интервал времени скрываем диалоговое окно
                setTimeout(() => {
                    dialog.classList.remove('show');
                }, displayTime);
            <?php endif; ?>
        </script>

        
        <?php if(session()->has('error_booking')): ?>
            <div class="error-dialog">
                <span class="error-message"><?php echo e(session('error_booking')); ?></span>
            </div>
        <?php endif; ?>
        <script>
            <?php if(session()->has('error_booking')): ?>
                var dialog = document.querySelector('.error-dialog');
                dialog.classList.add('show');
                const displayTime = 5000; // 5 секунд
                // Через заданный интервал времени скрываем диалоговое окно
                setTimeout(() => {
                    dialog.classList.remove('show');
                }, displayTime);
            <?php endif; ?>
        </script>

        
        <?php if(session()->has('booking_success')): ?>
            <div class="alert-success">
                <span class="error-message"><?php echo e(session('booking_success')); ?></span>
            </div>
        <?php endif; ?>
        <script>
            <?php if(session()->has('booking_success')): ?>
                var dialog = document.querySelector('.alert-success');
                dialog.classList.add('show');
                const displayTime = 5000; // 5 секунд
                // Через заданный интервал времени скрываем диалоговое окно
                setTimeout(() => {
                    dialog.classList.remove('show');
                }, displayTime);
            <?php endif; ?>
        </script>

        <div class="row">
            <div class="col-md-7">
                <img src="/img/<?php echo e($product->image); ?>" alt="<?php echo e($product->name); ?>" class="img-thumbnail w-100">
            </div>
            <div class="col-md-5 red-bg">
                <div class="poduct__right">
                    <div class="row">
                        <div class="col-md-7">
                            <h2 class="text-36px text-white mt-5"><?php echo e($product->name); ?></h2>
                        </div>
                        <div class="col-md-5">
                            <p class="rent_or_buy"><?php echo e($product->rent_or_buy); ?></p>
                        </div>
                    </div>
                    <?php if($product->rent_or_buy == 'Аренда'): ?>
                        <p class="product__price text-25px text-red mt-4 mb-5"><?php echo e($product->price); ?> руб./сутки.</p>
                    <?php else: ?>
                        <p class="product__price text-25px text-red mt-4 mb-5"><?php echo e($product->price); ?> руб.</p>
                    <?php endif; ?>

                    <p class="product__size mt-4 text-25px text-white">Размер: <strong
                            class="ms-2"><?php echo e($product->size); ?></strong></p>
                    <div class="mt-5 w-100 text-red">
                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                                <a href="<?php echo e(url('/login')); ?>" class="login__booking">Авторизоваться</a>
                            <?php endif; ?>
                        <?php else: ?>
                            <?php if($product->rent_or_buy == 'Аренда'): ?>
                                <form action="/bookings" method="post" class="d-flex flex-column pe-5 mt-5">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">

                                    <label for="date" class="text-white">Дата бронирования:</label>
                                    <input type="date" name="date" id="date" required value="<?php echo e(date('Y-m-d')); ?>"
                                        min="<?php echo e(now()->format('Y-m-d')); ?>">

                                    <script>
                                        // Получаем занятые даты из базы данных
                                        var occupiedDates = <?php echo json_encode($occupiedDates); ?>; // Замените $occupiedDates на фактический список занятых дат

                                        // Обработчик изменения значения инпута
                                        document.getElementById("date").addEventListener("change", function() {
                                            var selectedDate = this.value;
                                            var isDateOccupied = occupiedDates.includes(selectedDate);

                                            // Проверяем, выбрана ли занятая дата
                                            if (isDateOccupied) {
                                                alert("Эта дата уже занята. Выберите другую дату.");
                                                this.value = ""; // Сбрасываем выбранную дату
                                            }
                                        });
                                    </script>


                                    <?php if($user->phone == null): ?>
                                        <div class="form-group row">
                                            <label for="phone"
                                                class="col-form-label text-md-right text-white"><?php echo e(__('Номер телефона:')); ?></label>
                                            <div class="">
                                                <input id="phone" type="tel"
                                                    class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="phone"
                                                    value="<?php echo e(old('phone')); ?>" required autocomplete="phone" autofocus>
                                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    <?php endif; ?>

                                    <button type="submit" class="btn__in_cart mt-3">Забронировать</button>
                                </form>
                            <?php else: ?>
                                <form action="<?php echo e(route('cart.add', $product->id)); ?>" method="POST"
                                    class="d-flex flex-column pe-5">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn__in_cart mt-3">В корзину</button>
                                </form>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <p class="text-25px mt-5 text-white">Описание:<br><?php echo e($product->description); ?></p>
                </div>
            </div>
        </div>
    </div>
    <div class="index__catalog_items mt-5 mb-5">
        <div class="container">
            <div class="row">
                <?php if($products->isEmpty()): ?>
                    <h2 class="text-start ms-5 mb-3 text-36px index__catalog_title w-90"><strong>Наши новинки</strong></h2>
                    <div class="alert alert-danger m-0" role="alert">
                        <h2 class="m-0 p-0">Каталог пуст.</h2>
                    </div>
                <?php else: ?>
                    <h2 class="text-start ms-5 mb-5 text-36px index__catalog_title"><strong>Наши новинки</strong></h2>
                    <div class="d-flex justify-content-between flex-mobile-column ">
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="product mobile-product">
                                <a href="<?php echo e(route('product', $product->id)); ?>"
                                    class="text-black none-underline product_link p-relative h-100">
                                    <p class="catalog__rent_or_buy"><?php echo e($product->rent_or_buy); ?></p>
                                    <img src="/img/<?php echo e($product->image); ?>" alt="<?php echo e($product->name); ?>" class="h-100">
                                    <h3 class="mt-3 text-white text-25px w-250px text-center"><?php echo e($product->name); ?></h3>
                                    <p class="price text-25px w-100 text-center bg-light"><strong><?php echo e($product->price); ?>

                                            руб.</strong>
                                    </p>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <a class="w-100 text-center mt-5 text-black text-black_link" href="<?php echo e(url('/catalog')); ?>">Перейти к
                        каталогу</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\localhost-saukele\laravel\resources\views/product.blade.php ENDPATH**/ ?>