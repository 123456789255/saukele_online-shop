<?php $__env->startSection('content'); ?>
    <div class="container pt-3">
        <h1>Заказ <?php echo e($order->id); ?></h1>
        <p>Дата создания заказа: <?php echo e($order->created_at); ?> (+0 GMT)</p>
        <p>Статус заказа: <?php echo e($order->status); ?></p>
        <?php if($order->user_phone == null): ?>
            <p>Номер телефона: <a href="tel:<?php echo e($user->phone); ?>" class="text-black none-underline"><?php echo e($user->phone); ?></a></p>
        <?php else: ?>
            <p>Номер телефона: <a href="tel:<?php echo e($order->user_phone); ?>"
                    class="text-black none-underline"><?php echo e($order->user_phone); ?></a></p>
        <?php endif; ?>
        <p><strong>В ближайшее время с вами свяжется менеджер!</strong></p>
        <table class="table">
            <thead>
                <tr>
                    <th>Название</th>
                    <th>Количество</th>
                    <th>Цена за единицу</th>
                    <th>Итоговая стоимость</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->product->name); ?></td>
                        <td><?php echo e($item->quantity); ?></td>
                        <td><?php echo e($item->price); ?></td>
                        <td><?php echo e($item->quantity * $item->price); ?>руб.</td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <tr class="">
                    <td colspan="3">Общая стоимость: <strong class="ms-2">
                            <?php echo e($order->items->sum(function ($cart) {return $cart->product->price * $cart->quantity;})); ?>

                            руб.
                        </strong></td>
                    <td>
                        <?php if($order->status == 'Новый'): ?>
                            <form action="<?php echo e(route('orders.destroy', $order->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm">Удалить</button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            </tfoot>
        </table>
    </div>
    <div class="index__catalog_items mt-5 mb-5">
        <div class="container">
            <div class="row">
                <?php if($products->isEmpty()): ?>
                    <h2 class="text-start ms-5 mb-3 text-36px index__catalog_title w-90"><strong>Наши новинки</strong></h2>
                    <div class="alert alert-danger m-0" role="alert">
                        <h2 class="m-0 p-0">Каталог пуст.</h2>
                    </div>
                <?php else: ?>
                    <h2 class="text-start ms-5 mb-5 text-36px index__catalog_title"><strong>Наши новинки</strong></h2>
                    <div class="d-flex justify-content-between flex-mobile-column ">
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="product mobile-product">
                                <a href="<?php echo e(route('product', $product->id)); ?>"
                                    class="text-black none-underline product_link p-relative h-100">
                                    <p class="catalog__rent_or_buy"><?php echo e($product->rent_or_buy); ?></p>
                                    <img src="/img/<?php echo e($product->image); ?>" alt="<?php echo e($product->name); ?>" class="h-100">
                                    <h3 class="mt-3 text-white text-25px w-250px text-center"><?php echo e($product->name); ?></h3>
                                    <p class="price text-25px w-100 text-center bg-light"><strong><?php echo e($product->price); ?>

                                            руб.</strong>
                                    </p>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <a class="w-100 text-center mt-5 text-black text-black_link" href="<?php echo e(url('/catalog')); ?>">Перейти к
                        каталогу</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\localhost-saukele\laravel\resources\views/orders/show.blade.php ENDPATH**/ ?>