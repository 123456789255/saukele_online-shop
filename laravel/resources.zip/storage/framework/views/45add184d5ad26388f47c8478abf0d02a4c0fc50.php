<?php $__env->startSection('content'); ?>
    <div class="container admin__category z-index-1 pb-1 pt-3">
        <h1 class="mb-3 text-30px">Все пользователи</h1>
        <?php if(session('success')): ?>
            <div class="alert alert-success">Пользователь удален!</div>
        <?php endif; ?>
        <script>
            <?php if(session()->has('success')): ?>
                var dialog = document.querySelector('.alert-success');
                dialog.classList.add('show');
                const displayTime = 3000; // 5 секунд
                // Через заданный интервал времени скрываем диалоговое окно
                setTimeout(() => {
                    dialog.classList.remove('show');
                }, displayTime);
            <?php endif; ?>
        </script>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="users">
                <p>ID: <?php echo e($user->id); ?></p>
                <p>ФИО: <strong><?php echo e($user->surname); ?> <?php echo e($user->name); ?> <?php echo e($user->patronymic); ?></strong></p>
                <p>Логин: <?php echo e($user->login); ?></p>
                <p>E-mail: <?php echo e($user->email); ?></p>
                <div class="">
                    <p>Роль:</p>
                    <form class="d-flex mobile_d-block ms-3" method="post" action="<?php echo e(route('admin.updateUser', $user->id)); ?>"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <select name="role" class="form-control form-category col-md-2" id="role">
                            <?php if($user->role == '2'): ?>
                                <option value="2">Администратор</option>
                                <option value="1">Пользователь</option>
                            <?php else: ?>
                                <option value="1">Пользователь</option>
                                <option value="2">Администратор</option>
                            <?php endif; ?>

                        </select>

                        <button type="submit" class="btn btn-primary col-md-2 desktop-ms-5 mobile-mt-3">Сохранить</button>
                    </form>
                </div>
                
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\localhost-saukele\laravel\resources\views/admin/users.blade.php ENDPATH**/ ?>