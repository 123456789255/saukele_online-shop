<?php $__env->startSection('content'); ?>
    <div class="container cart pt-3">
        <?php if(session()->has('error')): ?>
            <div class="error-dialog">
                <span class="error-message"><?php echo e(session('error')); ?></span>
            </div>
        <?php endif; ?>
        <script>
            <?php if(session()->has('error')): ?>
                var dialog = document.querySelector('.error-dialog');
                dialog.classList.add('show');
                const displayTime = 5000; // 5 секунд
                // Через заданный интервал времени скрываем диалоговое окно
                setTimeout(() => {
                    dialog.classList.remove('show');
                }, displayTime);
            <?php endif; ?>
        </script>
        <?php if(session()->has('error_cart')): ?>
            <div class="error-dialog">
                <span class="error-message">Вы добавили в корзину больше товара чем есть на складе. На складе сейчас имеется
                    <?php echo e(session('error_cart')); ?> ед. товара.</span>
            </div>
        <?php endif; ?>
        <script>
            <?php if(session()->has('error_cart')): ?>
                var dialog = document.querySelector('.error-dialog');
                dialog.classList.add('show');
                const displayTime = 5000; // 5 секунд
                // Через заданный интервал времени скрываем диалоговое окно
                setTimeout(() => {
                    dialog.classList.remove('show');
                }, displayTime);
            <?php endif; ?>
        </script>
        <?php if($carts->isEmpty()): ?>
            <div class="card-header ms-5">
                <h1 class="mt-3 text-30px">Корзина</h1>
            </div>
            <div class="alert alert-info mb-5" role="alert">
                <h2 class="ms-5">Ой... похоже что ваша корзина пуста.</h2>
            </div>
        <?php else: ?>
            <div class="row cart__items">
                <div class="col-md-4 left">
                    <div class="card-header mt-3">
                        <h1 class="text-30px">Корзина</h1>
                    </div>
                    <p class="m-0 text-25px">Количество предметов в корзине: <strong><?php echo e($count); ?> шт.</strong></p>
                    <p class="m-0 text-25px">Общая стоимость:
                        <strong><?php echo e($carts->sum(function ($cart) {return $cart->product->price * $cart->quantity;})); ?>

                            руб.</strong>
                    </p>
                    
                    <form method="POST" action="<?php echo e(route('orders.store')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="phone"
                                class="col-md-5 col-form-label text-md-right"><?php echo e(__('Номер телефона')); ?></label>

                            <div class="col-md-6">
                                <input id="phone" type="tel"
                                    class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="phone"
                                    value="<?php echo e(old('phone')); ?>" required autocomplete="phone" autofocus>

                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row mb-0 mt-3">
                            <div>
                                <button type="submit" class="btn__catalog_in_cart btn btn-primary w-100">
                                    <?php echo e(__('Оформить заказ')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                    <p class="m-0 text-25px"><br>Наш менеджер в скором времени свяжется с вами!</p>
                </div>
                <div class="col-md-8 right">
                    <div class="d-none-desktop me-auto">
                        <h2 class="mt-5 mb-0">Содержимое корзины:</h2>
                    </div>
                    <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="busket-card row white-bg br-15px mb-4 me-4 w-100">
                            <div class="col-md-6 p-3 cart__left">
                                <a href="<?php echo e(route('product', $cart->product->id)); ?>">
                                    <img src="/img/<?php echo e($cart->product->image); ?>" alt="black-blue" class="w-100 cart__photo">
                                </a>
                            </div>
                            <div class="col-md-6 p-3 text-black cart__right">
                                <div class="d-flex">
                                    <p class="text-30px mt-3 me-auto"><strong><?php echo e($cart->Product->name); ?></strong></p>
                                    <a href="<?php echo e(route('cart.remove.all', ['cartId' => $cart->id])); ?>"
                                        class="mt-3 close-button ms-5" onclick="return confirm('Вы уверены?')">
                                        <img class="" src="img/close.svg" alt="">
                                    </a>
                                </div>
                                <div class="d-flex mt-4 mb-3">
                                    <p class="cart__product__size  mt-2 text24px400">Размер:
                                        <strong class="text-black ms-3"><?php echo e($cart->Product->size); ?></strong>
                                    </p>
                                </div>
                                <div class="quantity">
                                    <p class="mt-2 text24px400">Количество :</p>
                                    <div class="d-flex quantity_buttons text24px weight700">
                                        <a href="/remove-from-card/<?php echo e($cart->product_id); ?>" class="btn  minus me-3">-</a>
                                        <p class="m-0"><?php echo e($cart->quantity); ?> шт.</p>
                                        <a href="/add-on-cart/<?php echo e($cart->product_id); ?>" class="btn btn-primary plus ms-3"
                                            id="add-to-cart-btn">+</a>
                                    </div>
                                </div>
                                <p class="cart__price mt-5 mt-2"><?php echo e(intval($cart->Product->price) * $cart->quantity); ?> руб.
                                </p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <div class="index__catalog_items cart_new_items mb-5">
        <div class="container">
            <div class="row">
                <?php if($products->isEmpty()): ?>
                    <h2 class="text-start mb-3 text-36px  w-90"><strong>ОЙ...</strong></h2>
                    <div class="alert alert-danger m-0" role="alert">
                        <h2 class="m-0 p-0">Каталог пуст.</h2>
                    </div>
                <?php else: ?>
                    <h2 class="text-start mb-5 text-36px "><strong>Вы так же можете посмотреть другие товары:</strong></h2>
                    <div class="d-flex justify-content-between flex-mobile-column ">
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="product mobile-product">
                                <a href="<?php echo e(route('product', $product->id)); ?>" class="none-underline">
                                    <img src="/img/<?php echo e($product->image); ?>" alt="<?php echo e($product->name); ?>" class="h-100">
                                    <h3 class="mt-3 text-white text-25px"><?php echo e($product->name); ?></h3>
                                    <p class="price text-25px w-100 text-center"><strong><?php echo e($product->price); ?>

                                            руб.</strong>
                                    </p>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <a class="w-100 text-center mt-5 text-black" href="<?php echo e(url('/catalog')); ?>">Перейти к
                        каталогу</a>
                <?php endif; ?>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/o/otau2ru/public_html/laravel/resources/views/cart.blade.php ENDPATH**/ ?>