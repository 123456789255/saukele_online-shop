<?php $__env->startSection('content'); ?>
    <div class="container pt-3">
        <?php if(session()->has('profile_password')): ?>
            <div class="error-dialog">
                <span class="error-message"><?php echo e(session('profile_password')); ?></span>
            </div>
        <?php endif; ?>
        <script>
            <?php if(session()->has('profile_password')): ?>
                var dialog = document.querySelector('.error-dialog');
                dialog.classList.add('show');
                const displayTime = 5000; // 5 секунд
                // Через заданный интервал времени скрываем диалоговое окно
                setTimeout(() => {
                    dialog.classList.remove('show');
                }, displayTime);
            <?php endif; ?>
        </script>
        <div class="profile_title d-flex">
            <h1>Профиль</h1>
            <div class="d-flex align-center ms-auto">
                <a class="btn btn-danger align-center d-flex" href="<?php echo e(route('logout')); ?>"
                    onclick="event.preventDefault();
                                                document.getElementById('logout-form').submit();">Выход
                    из профиля</a>

                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
            </div>
        </div>
        <div>
            <p>Логин: <strong><?php echo e($user->login); ?></strong></p>
        </div>
        <form action="<?php echo e(route('profile.update')); ?>" method="post" class=" mt-3">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="surname">Email</label>
                <input type="email" class="form-control" id="email" name="email" value="<?php echo e($user->email); ?>">
            </div>

            <div class="form-group">
                <label for="surname">Фамилия</label>
                <input type="text" class="form-control" id="surname" name="surname" value="<?php echo e($user->surname); ?>">
            </div>

            <div class="form-group mt-3">
                <label for="name">Имя</label>
                <input type="text" class="form-control mt-1" id="name" name="name" value="<?php echo e($user->name); ?>">
            </div>

            <div class="form-group mt-3">
                <label for="patronymic">Отчество</label>
                <input type="text" class="form-control mt-1" id="patronymic" name="patronymic"
                    value="<?php echo e($user->patronymic); ?>">
            </div>

            <div class="form-group mt-3">
                <label for="patronymic">Номер телефона</label>
                <input id="phone" type="tel" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    name="phone" value="<?php echo e($user->phone); ?>" required autocomplete="phone" autofocus>
            </div>

            <button type="submit" class="btn btn-primary btn__catalog_in_cart mt-3">Изменить</button>
        </form>

        <form action="<?php echo e(route('profile.update-password')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group mt-3">
                <label for="password">Новый пароль</label>
                <input type="password" class="form-control mt-1" id="password" name="password">
            </div>

            <div class="form-group mt-3">
                <label for="password_confirmation">Повторите новый пароль</label>
                <input type="password" class="form-control mt-1" id="password_confirmation" name="password_confirmation">
            </div>

            <button type="submit" class="btn btn-primary btn__catalog_in_cart mt-3">Изменить пароль</button>
        </form>
    </div>
    <div class="index__catalog_items mt-5 mb-5">
        <div class="container">
            <div class="row">
                <?php if($products->isEmpty()): ?>
                    <h2 class="text-start ms-5 mb-3 text-36px index__catalog_title w-90"><strong>Наши новинки</strong></h2>
                    <div class="alert alert-danger m-0" role="alert">
                        <h2 class="m-0 p-0">Каталог пуст.</h2>
                    </div>
                <?php else: ?>
                    <h2 class="text-start ms-5 mb-5 text-36px index__catalog_title"><strong>Наши новинки</strong></h2>
                    <div class="d-flex justify-content-between flex-mobile-column ">
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="product mobile-product">
                                <a href="<?php echo e(route('product', $product->id)); ?>"
                                    class="text-black none-underline product_link p-relative h-100">
                                    <p class="catalog__rent_or_buy"><?php echo e($product->rent_or_buy); ?></p>
                                    <img src="/img/<?php echo e($product->image); ?>" alt="<?php echo e($product->name); ?>" class="h-100">
                                    <h3 class="mt-3 text-white text-25px w-250px text-center"><?php echo e($product->name); ?></h3>
                                    <p class="price text-25px w-100 text-center bg-light"><strong><?php echo e($product->price); ?>

                                            руб.</strong>
                                    </p>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <a class="w-100 text-center mt-5 text-black text-black_link" href="<?php echo e(url('/catalog')); ?>">Перейти к
                        каталогу</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\localhost-saukele\laravel\resources\views/user.blade.php ENDPATH**/ ?>