<?php $__env->startSection('content'); ?>
    <div class="container pt-3">
        <?php if(session()->has('profile_password')): ?>
            <div class="error-dialog">
                <span class="error-message"><?php echo e(session('profile_password')); ?></span>
            </div>
        <?php endif; ?>
        <script>
            <?php if(session()->has('profile_password')): ?>
                var dialog = document.querySelector('.error-dialog');
                dialog.classList.add('show');
                const displayTime = 5000; // 5 секунд
                // Через заданный интервал времени скрываем диалоговое окно
                setTimeout(() => {
                    dialog.classList.remove('show');
                }, displayTime);
            <?php endif; ?>
        </script>
        <div class="profile_title d-flex">
            <h1>Профиль</h1>
            <div class="d-flex align-center ms-auto">
                <a class="btn btn-danger align-center d-flex" href="<?php echo e(route('logout')); ?>"
                    onclick="event.preventDefault();
                                                document.getElementById('logout-form').submit();">Выход
                    из профиля</a>

                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
            </div>
        </div>
        <div>
            <p>Логин: <strong><?php echo e($user->login); ?></strong></p>

            <p>Email: <strong><?php echo e($user->email); ?></strong></p>
        </div>
        <form action="<?php echo e(route('profile.update')); ?>" method="post" class=" mt-3">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="surname">Фамилия</label>
                <input type="text" class="form-control" id="surname" name="surname" value="<?php echo e($user->surname); ?>">
            </div>

            <div class="form-group mt-3">
                <label for="name">Имя</label>
                <input type="text" class="form-control mt-1" id="name" name="name" value="<?php echo e($user->name); ?>">
            </div>

            <div class="form-group mt-3">
                <label for="patronymic">Отчество</label>
                <input type="text" class="form-control mt-1" id="patronymic" name="patronymic"
                    value="<?php echo e($user->patronymic); ?>">
            </div>

            <button type="submit" class="btn btn-primary btn__catalog_in_cart mt-3">Изменить</button>
        </form>

        <form action="<?php echo e(route('profile.update-password')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group mt-3">
                <label for="password">Новый пароль</label>
                <input type="password" class="form-control mt-1" id="password" name="password">
            </div>

            <div class="form-group mt-3">
                <label for="password_confirmation">Повторите новый пароль</label>
                <input type="password" class="form-control mt-1" id="password_confirmation" name="password_confirmation">
            </div>

            <button type="submit" class="btn btn-primary btn__catalog_in_cart mt-3">Изменить пароль</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/o/otau2ru/public_html/laravel/resources/views/user.blade.php ENDPATH**/ ?>