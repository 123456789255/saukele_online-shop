<?php $__env->startSection('content'); ?>
    <div class="container pt-3">
        <?php if(session()->has('booking_delete')): ?>
            <div class="alert-success">
                <span class="error-message"><?php echo e(session('booking_delete')); ?></span>
            </div>
        <?php endif; ?>
        <script>
            <?php if(session()->has('booking_delete')): ?>
                var dialog = document.querySelector('.alert-success');
                dialog.classList.add('show');
                const displayTime = 5000; // 5 секунд
                // Через заданный интервал времени скрываем диалоговое окно
                setTimeout(() => {
                    dialog.classList.remove('show');
                }, displayTime);
            <?php endif; ?>
        </script>
        <?php if(session()->has('order_delete')): ?>
            <div class="alert-success">
                <span class="error-message"><?php echo e(session('order_delete')); ?></span>
            </div>
        <?php endif; ?>
        <script>
            <?php if(session()->has('order_delete')): ?>
                var dialog = document.querySelector('.alert-success');
                dialog.classList.add('show');
                const displayTime = 5000; // 5 секунд
                // Через заданный интервал времени скрываем диалоговое окно
                setTimeout(() => {
                    dialog.classList.remove('show');
                }, displayTime);
            <?php endif; ?>
        </script>
        <div class="col-md-12 d-flex">
            <h1><strong>Мои заказы</strong></h1>
            <a href="#booking" class="booking__href text-black text-black_link">Забронированные товары</a>
        </div>
        <?php if(count($orders) > 0): ?>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="orders mt-2 mb-3">
                    <p><?php echo e($order->created_at); ?> (+0 GMT)</p>
                    <p>ФИО: <strong><?php echo e($order->user->surname); ?> <?php echo e($order->user->name); ?>

                            <?php echo e($order->user->patronymic); ?></strong>
                    </p>
                    <p class="">Статус
                        <?php if($order->status == 'Подтвержден'): ?>
                            <strong class="  btn btn-success m-auto text-25px"><?php echo e($order->status); ?></strong>
                        <?php elseif($order->status == 'Отменен'): ?>
                            <strong class="  btn btn-danger m-auto text-25px"><?php echo e($order->status); ?></strong>
                        <?php elseif($order->status !== 'Отменен' && $order->status !== 'Подтвержден'): ?>
                            <strong class="btn__catalog_in_cart  btn btn-primary m-auto text-25px">Новый</strong>
                        <?php endif; ?>
                    </p>
                    <p>Количество товаров: <?php echo e($order->items->sum('quantity')); ?></p>
                    <p class="border_strong">Сумма:
                        <strong><?php echo e($order->items->sum(function ($cart) {return $cart->product->price * $cart->quantity;})); ?>

                            руб.</strong>
                    </p>
                    <?php if($order->status == 'Новый'): ?>
                        <div class="d-flex">
                            <a href="<?php echo e(route('orders.show', ['order' => $order->id])); ?>"
                                class=" btn__catalog_in_cart btn btn-primary">
                                <?php echo e(__('Просмотреть')); ?>

                            </a>
                            <form action="<?php echo e(route('orders.destroy', $order->id)); ?>" method="POST" class="ms-1">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm h-100">Удалить</button>
                            </form>
                        </div>
                    <?php else: ?>
                        <a href="<?php echo e(route('orders.show', ['order' => $order->id])); ?>"
                            class="btn__catalog_in_cart btn btn-primary">
                            <?php echo e(__('Просмотреть')); ?>

                        </a>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <div class="alert alert-info" role="alert">
                У вас пока нет заказов
            </div>
        <?php endif; ?>
        <div>
            <h2 id="booking"><strong>Мои бронирования</strong></h2>
        </div>
        <?php if(count($bookings) > 0): ?>
            <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bookings ms-0 w-100 row mt-2 mb-3">
                    <div class="col-md-2">
                        <a href="<?php echo e(route('product', $booking->product->id)); ?>" class="text-white">
                            <img src="/img/<?php echo e($booking->product->image); ?>" alt="black-blue" class="w-100 cart__photo">
                        </a>
                    </div>
                    <div class="col-md-6 mobile_mt-3">
                        <h3>Было забронированно:</h3>
                        <p>Название: <strong><a class="text-black none-underline"
                                    href="<?php echo e(route('product', $booking->product->id)); ?>"><?php echo e($booking->product->name); ?></a></strong>
                        </p>
                        <p class="">Статус
                            <?php if($booking->status == 'Подтвержден'): ?>
                                <strong class="  btn btn-success m-auto text-25px"><?php echo e($booking->status); ?></strong>
                            <?php elseif($booking->status == 'Отменен'): ?>
                                <strong class="  btn btn-danger m-auto text-25px"><?php echo e($booking->status); ?></strong>
                            <?php elseif($booking->status !== 'Отменен' && $booking->status !== 'Подтвержден'): ?>
                                <strong class="btn__catalog_in_cart  btn btn-primary m-auto text-25px">Новый</strong>
                            <?php endif; ?>
                        </p>
                        <p>Дата: <strong><?php echo e($booking->date); ?></strong></p>
                        <?php if($booking->status == 'Новый'): ?>
                            <form action="<?php echo e(route('bookings.destroy', $booking)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm h-100">Удалить</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <div class="alert alert-info" role="alert">
                У вас пока забронированных товаров
            </div>
        <?php endif; ?>
    </div>
    <div class="index__catalog_items mt-5 mb-5">
        <div class="container">
            <div class="row">
                <?php if($products->isEmpty()): ?>
                    <h2 class="text-start ms-5 mb-3 text-36px index__catalog_title w-90"><strong>Наши новинки</strong></h2>
                    <div class="alert alert-danger m-0" role="alert">
                        <h2 class="m-0 p-0">Каталог пуст.</h2>
                    </div>
                <?php else: ?>
                    <h2 class="text-start ms-5 mb-5 text-36px index__catalog_title"><strong>Наши новинки</strong></h2>
                    <div class="d-flex justify-content-between flex-mobile-column ">
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="product mobile-product">
                                <a href="<?php echo e(route('product', $product->id)); ?>"
                                    class="text-black none-underline product_link p-relative h-100">
                                    <p class="catalog__rent_or_buy"><?php echo e($product->rent_or_buy); ?></p>
                                    <img src="/img/<?php echo e($product->image); ?>" alt="<?php echo e($product->name); ?>" class="h-100">
                                    <h3 class="mt-3 text-white text-25px w-250px text-center"><?php echo e($product->name); ?></h3>
                                    <p class="price text-25px w-100 text-center bg-light"><strong><?php echo e($product->price); ?>

                                            руб.</strong>
                                    </p>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <a class="w-100 text-center mt-5 text-black text-black_link" href="<?php echo e(url('/catalog')); ?>">Перейти к
                        каталогу</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\localhost-saukele\laravel\resources\views/orders/index.blade.php ENDPATH**/ ?>