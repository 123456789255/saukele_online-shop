

<?php $__env->startSection('content'); ?>
    <div class="container pt-3 pb-5 z-index-1">
        <h1>Бронирования пользователей</h1>
        <form action="<?php echo e(route('admin.showBooking')); ?>" method="GET">
            <div class="form-group">
                <label for="status">Статус:</label>
                <select name="status" id="status" class="form-control mt-2 mb-2">
                    <option value=""
                        <?php echo e($status !== 'Новый' && $status !== 'Подтвержден' && $status === 'Отменен' ? 'selected' : ''); ?>>
                        Все</option>
                    <option value="Новый" <?php echo e($status === 'Новый' ? 'selected' : ''); ?>>Новый</option>
                    <option value="Подтвержден" <?php echo e($status === 'Подтвержден' ? 'selected' : ''); ?>>
                        Подтвержденный</option>
                    <option value="Отменен" <?php echo e($status === 'Отменен' ? 'selected' : ''); ?>>Отмененный
                    </option>
                </select>
            </div>
            <button type="submit" class="btn__catalog_in_cart btn btn-primary">Фильтр</button>
        </form>
        <?php if($bookings->isEmpty()): ?>
            <div class="alert alert-info mb-5" role="alert">
                <h2 class="ms-5">Забронированные товары отсутствуют</h2>
            </div>
        <?php else: ?>
            <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bookings ms-0 w-100 row mt-2 mb-3">
                    <div class="col-md-2">
                        <a href="<?php echo e(route('product', $booking->product->id)); ?>" class="text-white">
                            <img src="/img/<?php echo e($booking->product->image); ?>" alt="black-blue" class="w-100 cart__photo">
                        </a>
                    </div>
                    <div class="col-md-6 mobile_mt-3">
                        <h3>Было забронированно:</h3>
                        <p>Пользователем: <strong><?php echo e($user->name); ?> <?php echo e($user->surname); ?> <?php echo e($user->patronymic); ?></strong>
                        </p>
                        <?php if($user->phone == null): ?>
                            <p>Номер телефона пользователя: <strong><a class="text-black"
                                        href="tel:<?php echo e($booking->phone); ?>"><?php echo e($booking->phone); ?></a></strong></p>
                        <?php else: ?>
                            <p>Номер телефона пользователя: <strong><a class="text-black"
                                        href="tel:<?php echo e($user->phone); ?>"><?php echo e($user->phone); ?></a></strong></p>
                        <?php endif; ?>
                        <p class="">Статус
                            <?php if($booking->status == 'Подтвержден'): ?>
                                <strong class="btn btn-success m-auto text-25px"><?php echo e($booking->status); ?></strong>
                            <?php elseif($booking->status == 'Отменен'): ?>
                                <strong class="btn btn-danger m-auto text-25px"><?php echo e($booking->status); ?></strong>
                            <?php elseif($booking->status !== 'Отменен' && $booking->status !== 'Подтвержден'): ?>
                                <strong class="btn btn-primary m-auto text-25px">Новый</strong>
                            <?php endif; ?>
                        </p>
                        <p>Название: <strong><a class="text-black none-underline"
                                    href="<?php echo e(route('product', $booking->product->id)); ?>"><?php echo e($booking->product->name); ?></a></strong>
                        </p>
                        <p>Дата: <strong><?php echo e($booking->date); ?></strong> (ГГГГ-ММ-ДД)</p>
                        <div class="d-flex mobile_none_d-flex mobile_gap-8px">
                            <form method="POST" action="<?php echo e(route('admin.cancelBooking', $booking->id)); ?>"
                                class="mobile_ms-0">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-danger text-25px">Отменить</button>
                            </form>
                            <form method="POST" action="<?php echo e(route('admin.confirmBooking', $booking->id)); ?>"
                                class="mobile_ms-0 ms-3">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-success text-25px">Подтвердить</button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\localhost-saukele\laravel\resources\views/admin/booking.blade.php ENDPATH**/ ?>