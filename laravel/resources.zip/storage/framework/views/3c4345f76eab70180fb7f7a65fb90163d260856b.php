<?php $__env->startSection('content'); ?>
    <div class="container admin__category z-index-1 pt-3 pb-1">
        <div class="row cart__items">
            <div class="col-md-4 left">
                <h1 class="mb-3 text-30px">Добавить Категорию</h1>
                <form action="<?php echo e(route('admin.addCategory')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label class="text-25px" for="name">Название категории:</label>
                        <input type="text" name="name" id="name" class="form-control mb-2 text-25px">
                    </div>
                    <button type="submit" class="btn btn-primary text-25px mt-3">Добавить</button>
                </form>
            </div>
            <div class="col-md-7 right ms-5">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="p-3 busket-card row white-bg br-15px mb-4 me-4 w-100">
                        <div class="d-flex justify-content-">
                            <p class="text-25px me-3 mt-3"><strong>№<?php echo e($category->id); ?></strong></p>
                            <label for="category_name<?php echo e($category->id); ?>"
                                class="text-25px text24px400 mt-3 name__category">Название категории: </p>
                        </div>
                        <div class="d-flex">
                            <form method="post" action="<?php echo e(route('admin.updateCategories', $category->id)); ?>"
                                enctype="multipart/form-data" class="d-flex">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>

                                <div class="form-group">
                                    <input type="text" class="form-control mb-2 text-30px"
                                        id="category_name<?php echo e($category->id); ?>" name="category_name<?php echo e($category->id); ?>"
                                        value="<?php echo e($category->name_category); ?>">
                                </div>


                                <div class="d-flex align-center flex_mobile ms-md-1 ms-1">
                                    <button type="submit" class="btn btn-primary text-25px">Изменить</button>
                                </div>
                            </form>
                            <div class="d-flex align-center flex_mobile ms-1">
                                <form action="<?php echo e(route('admin.deleteCategories', ['id' => $category->id])); ?>" method="POST"
                                    style="display: inline-block;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger text-25px"
                                        onclick="return confirm('Вы уверены?')">Удалить</button>
                                </form>
                            </div>
                        </div>

                        <p>Подкатегории:</p>
                        <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($sub->category_id == $category->id): ?>
                                <div class="d-md-flex w-100 mb-2">
                                    <div class="d-flex">
                                        <p class="me-3">№<?php echo e($sub->id); ?></p>
                                        <label for="edit_subcategory_name<?php echo e($sub->id); ?>">Название
                                            подкатегории</label>
                                    </div>
                                    <div class="d-flex">
                                        <form method="post" action="<?php echo e(route('admin.updateSubcategory', $category->id)); ?>"
                                            enctype="multipart/form-data" class="d-flex w-100">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <div class="form-group d-flex w-100">

                                                <input type="text" class="form-control"
                                                    id="edit_subcategory_name<?php echo e($sub->id); ?>"
                                                    name="edit_subcategory_name<?php echo e($sub->id); ?>"
                                                    value="<?php echo e($sub->name); ?>">
                                            </div>
                                            <button class="btn btn-primary ms-1" type="submit">Изменить</button>
                                        </form>
                                        <div class="d-flex align-center flex_mobile ms-1">
                                            <form action="<?php echo e(route('admin.deleteSubcategories', ['id' => $sub->id])); ?>"
                                                method="POST" style="display: inline-block;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger text-25px"
                                                    onclick="return confirm('Вы уверены?')">Удалить</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <form action="<?php echo e(route('admin.addSubcategory')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label class="text-25px" for="subcategory_name<?php echo e($category->id); ?>">Название
                                    подкатегории:</label>
                                <input type="text" name="subcategory_name<?php echo e($category->id); ?>"
                                    id="subcategory_name<?php echo e($category->id); ?>" class="form-control mb-2 text-25px">
                                <input type="text" name="sub_cat" id="sub_cat"
                                    class="form-control mb-2 text-25px d-none" value="<?php echo e($category->id); ?>">
                            </div>
                            <button type="submit" class="btn btn-primary text-25px mt-1">Добавить</button>
                        </form>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\localhost-saukele\laravel\resources\views/admin/categories.blade.php ENDPATH**/ ?>