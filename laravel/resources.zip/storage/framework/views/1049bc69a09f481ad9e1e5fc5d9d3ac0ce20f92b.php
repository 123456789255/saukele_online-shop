<?php $__env->startSection('content'); ?>
    <div class="container pt-3">
        <div class="col-md-12">
            <h1>Мои заказы</h1>
        </div>
        <?php if(count($orders) > 0): ?>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="orders mt-2 mb-3">
                    <p><?php echo e($order->created_at); ?> (+0 GMT)</p>
                    <p>ФИО: <strong><?php echo e($order->user->surname); ?> <?php echo e($order->user->name); ?>

                            <?php echo e($order->user->patronymic); ?></strong>
                    </p>
                    <p class="">Статус
                        <?php if($order->status == 'Подтвержден'): ?>
                            <strong
                                class="  btn btn-success m-auto text-25px"><?php echo e($order->status); ?></strong>
                        <?php elseif($order->status == 'Отменен'): ?>
                            <strong
                                class="  btn btn-danger m-auto text-25px"><?php echo e($order->status); ?></strong>
                        <?php elseif($order->status !== 'Отменен' && $order->status !== 'Подтвержден'): ?>
                            <strong class="btn__catalog_in_cart  btn btn-primary m-auto text-25px">Новый</strong>
                        <?php endif; ?>
                    </p>
                    <p>Количество товаров: <?php echo e($order->items->sum('quantity')); ?></p>
                    <p class="border_strong">Сумма:
                        <strong><?php echo e($order->items->sum(function ($cart) {return $cart->product->price * $cart->quantity;})); ?>

                            руб.</strong>
                    </p>
                    <?php if($order->status == 'Новый'): ?>
                        <div class="d-flex">
                            <a href="<?php echo e(route('orders.show', ['order' => $order->id])); ?>" class=" btn__catalog_in_cart btn btn-primary">
                                <?php echo e(__('Просмотреть')); ?>

                            </a>
                            <form action="<?php echo e(route('orders.destroy', $order->id)); ?>" method="POST" class="ms-1">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm h-100">Удалить</button>
                            </form>
                        </div>
                    <?php else: ?>
                        <a href="<?php echo e(route('orders.show', ['order' => $order->id])); ?>" class="btn__catalog_in_cart btn btn-primary">
                            <?php echo e(__('Просмотреть')); ?>

                        </a>
                    <?php endif; ?>
                </div>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <div class="alert alert-info" role="alert">
                У вас пока нет заказов
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/o/otau2ru/public_html/laravel/resources/views/orders/index.blade.php ENDPATH**/ ?>