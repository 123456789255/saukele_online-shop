

<?php $__env->startSection('content'); ?>
    <div class="container h-100vh w-100vw">
        <div class="d-flex justify-content-center"><h1>У вас нет доступа</h1></div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\localhost-saukele\laravel\resources\views/admin/none-admin.blade.php ENDPATH**/ ?>