<?php $__env->startSection('content'); ?>
    <div class="container h-100vh align-center d-flex justify-content-center">
        <div class="d-flex justify-content-center"><h1>У вас нет доступа</h1></div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/o/otau2ru/public_html/laravel/resources/views/admin/none-admin.blade.php ENDPATH**/ ?>