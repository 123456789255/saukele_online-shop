<?php $__env->startSection('content'); ?>
    <div class="container h-23vh w-100 admin__index pt-5">
        <div class="d-flex justify-content-around align-center h-100 w-100 align-center flex_mobile">
            <a href="<?php echo e(route('admin.orders')); ?>" class="btn__catalog_in_cart  btn btn-success ">Просмотр и редактирование заказов</a>
            <a href="<?php echo e(route('admin.products')); ?>" class="btn__catalog_in_cart 
 btn btn-primary ">Добавление и редактирование товаров в каталоге</a>
            <a href="<?php echo e(route('admin.category')); ?>" class="btn__catalog_in_cart 
 btn btn-danger ">Добавление и удаление категорий</a>
            <a href="<?php echo e(route('admin.users')); ?>" class="btn__catalog_in_cart text-white btn btn-info ">Пользователи</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/o/otau2ru/public_html/laravel/resources/views/admin/admin.blade.php ENDPATH**/ ?>