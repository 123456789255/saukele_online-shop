<?php $__env->startSection('content'); ?>
    <div class="container catalog mb-5 pt-5 z-index-1">
        <?php if(session()->has('error_catalog')): ?>
            <div class="error-dialog">
                <span class="error-message"><?php echo e(session('error_catalog')); ?></span>
            </div>
        <?php endif; ?>
        <script>
            <?php if(session()->has('error_catalog')): ?>
                var dialog = document.querySelector('.error-dialog');
                dialog.classList.add('show');
                const displayTime = 5000; // 5 секунд
                // Через заданный интервал времени скрываем диалоговое окно
                setTimeout(() => {
                    dialog.classList.remove('show');
                }, displayTime);
            <?php endif; ?>
        </script>
        <h1 class="text-36px ms-5">Каталог товаров</h1>
        <div class="row">
            <div class="col-md-2 left">
                <div class="filters">
                    <form action="<?php echo e(route('catalog')); ?>" method="GET">
                        <div class="form-group mb-3">
                            <label for="gender mb-2">Пол:</label>
                            <select name="gender" class="form-control form-category" id="gender">
                                <option value="" <?php echo e(request()->input('gender') == '' ? 'selected' : ''); ?>>Выбор</option>
                                <option value="Мужской" <?php echo e(request()->input('gender') == 'Мужской' ? 'selected' : ''); ?>>Мужской</option>
                                <option value="Женский" <?php echo e(request()->input('gender') == 'Женский' ? 'selected' : ''); ?>>Женский</option>
                            </select>

                        </div>
                        <div class="form-group mb-3">
                            <label for="rent_or_buy mb-2">Выберите метод<br>покупкa или арендa:</label>
                            <select name="rent_or_buy" class="form-control form-category" id="rent_or_buy">
                                <option value="" <?php echo e(request()->input('rent_or_buy') == '' ? 'selected' : ''); ?>>Выбор</option>
                                <option value="Покупка" <?php echo e(request()->input('rent_or_buy') == 'Покупка' ? 'selected' : ''); ?>>Покупка</option>
                                <option value="Аренда" <?php echo e(request()->input('rent_or_buy') == 'Аренда' ? 'selected' : ''); ?>>Аренда</option>
                            </select>
                        </div>
                        <div class="form-group mb-3">
                            <label for="category mb-2">Категория:</label>
                            <select name="category" class="form-control form-category" id="category">
                                <option value="">Все категории</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>" <?php echo e(request()->input('category') == $category->id ? 'selected' : ''); ?>><?php echo e($category->name_category); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="d-flex flex-column mb-3">
                            <label>Сортировка:</label>
                            <div class="ms-2 form-check">
                                <input class="form-check-input" type="radio" name="sort_by" id="sort_by_name"
                                    value="name" <?php echo e(request()->input('sort_by') == 'name' ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="sort_by_name">
                                    По наименованию
                                </label>
                            </div>
                            <div class="ms-2 form-check">
                                <input class="form-check-input" type="radio" name="sort_by" id="sort_by_price"
                                    value="price" <?php echo e(request()->input('sort_by') == 'price' ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="sort_by_price">
                                    По цене
                                </label>
                            </div>
                            <div class="ms-2 form-check">
                                <input class="form-check-input" type="radio" name="sort_by" id="sort_by_created_at"
                                    value="created_at" <?php echo e(request()->input('sort_by') == 'created_at' ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="sort_by_created_at">
                                    По новизне
                                </label>
                            </div>
                            <label>Сортировка по:</label>
                            <div class="ms-2 form-check">
                                <input class="form-check-input" type="radio" name="sort_direction" id="sort_direction_asc"
                                    value="asc" <?php echo e(request()->input('sort_direction') == 'asc' ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="sort_direction_asc">
                                    По возрастанию
                                </label>
                            </div>
                            <div class="ms-2 form-check">
                                <input class="form-check-input" type="radio" name="sort_direction"
                                    id="sort_direction_desc" value="desc"
                                    <?php echo e(request()->input('sort_direction') == 'desc' ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="sort_direction_desc">
                                    По убыванию
                                </label>
                            </div>
                        </div>
                        <button type="submit" class="btn__catalog_in_cart btn btn-primary">Применить</button>
                    </form>
                </div>
            </div>
            <div class="col-md-10 right">
                <div class="products">
                    <?php if($products->isEmpty()): ?>
                        <div class="alert alert-danger w-100 m-0" role="alert">
                            <h2 class="m-0 p-0">Каталог пуст.</h2>
                        </div>
                    <?php else: ?>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="product">
                                <a href="<?php echo e(route('product', $product->id)); ?>"
                                    class="text-black none-underline product_link p-relative">
                                    <p class="catalog__rent_or_buy"><?php echo e($product->rent_or_buy); ?></p>
                                    <img src="/img/<?php echo e($product->image); ?>" alt="<?php echo e($product->name); ?>" class="w-100 h-100">
                                    <h3 class="mt-3 text-red text-center"><strong><?php echo e($product->name); ?></strong></h3>
                                    <p class="price w-100 text-center text-25px m-0 p-0"><?php echo e($product->price); ?> руб.</p>
                                    <form action="<?php echo e(route('cart.add', ['productId' => $product->id])); ?>" method="POST"
                                        class="w-100">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit"
                                            class="btn__catalog_in_cart btn btn-primary w-100 mt-3 text-25px ">Добавить в
                                            корзину</button>
                                    </form>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/o/otau2ru/public_html/laravel/resources/views/catalog.blade.php ENDPATH**/ ?>