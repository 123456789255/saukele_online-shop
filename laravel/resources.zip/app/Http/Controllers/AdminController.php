<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Order;
use App\Models\Product;
use App\Models\Category;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use App\Models\Booking;
use App\Models\Subcategory;
use Illuminate\Support\Facades\Auth;

class AdminController extends Controller
{
    public function adminIndex()
    {
        if (!Auth::check()) {
            return redirect()->route('login');
        }
        if (Auth::user()->role == '2')
            return view('admin.admin');
        else
            return view('admin.none-admin');
    }

    public function orders(Request $request)
    {
        $status = $request->get('status');

        $orders = Order::query();

        if ($status) {
            $orders->where('status', $status);
        }

        $orders = $orders->orderBy('created_at', 'desc')->paginate(100000000);

        if (!Auth::check()) {
            return redirect()->route('login');
        }
        if (Auth::user()->role == '2')
            return view('admin.orders', compact('orders', 'status'));
        else
            return view('admin.none-admin');
    }

    public function viewOrder($id)
    {
        $order = Order::findOrFail($id);
        $user = Auth::user();

        if (!Auth::check()) {
            return redirect()->route('login');
        }
        if (Auth::user()->role == '2')
            return view('admin.view_order', compact('order', 'user'));
        else
            return view('admin.none-admin');
    }

    public function cancelOrder($id)
    {
        $order = Order::findOrFail($id);

        $order->status = 'Отменен';
        $order->save();

        if (!Auth::check()) {
            return redirect()->route('login');
        }
        if (Auth::user()->role == '2')
            return redirect()->back()->with('success', 'Заказ отменен.');
        else
            return view('admin.none-admin');
    }

    public function confirmOrder($id)
    {
        $order = Order::findOrFail($id);

        $order->status = 'Подтвержден';
        $order->save();

        if (!Auth::check()) {
            return redirect()->route('login');
        }
        if (Auth::user()->role == '2')
            return redirect()->back()->with('success', 'Заказ подтвержден.');
        else
            return view('admin.none-admin');
    }

    public function products(Request $request)
    {
        $search = $request->get('search');

        $category = DB::table('categories')->get();

        $subcategories = DB::table('subcategories')->get();

        $products = Product::query();

        if ($search) {
            $products->where('name', 'like', '%' . $search . '%');
        }

        $products = $products->orderBy('created_at', 'desc')->paginate(10);

        if (!Auth::check()) {
            return redirect()->route('login');
        }
        if (Auth::user()->role == '2')
            return view('admin.products', compact('products', 'search', 'category', 'subcategories'));
        else
            return view('admin.none-admin');
    }

    public function addProduct(Request $request)
    {
        $file = $request->file('image');
        $filename = time() . $file->getClientOriginalName();
        $file->move('img', $filename);

        $product = new Product;



        $product->name = $request->get('name');
        $product->image = $filename;

        // $product->image = $request->get('image');
        // // Сохраняем картинку на сервере и получаем имя файла
        // if ($request->hasFile('image')) {
        //     $filenameWithExt = $request->file('image')->getClientOriginalName();
        //     $filename = pathinfo($filenameWithExt, PATHINFO_FILENAME);
        //     $extension = $request->file('image')->getClientOriginalExtension();
        //     $fileNameToStore = $filename . '_' . time() . '.' . $extension;
        //     $path = $request->file('image')->storeAs('public/img', $fileNameToStore);
        //     $product->image = $fileNameToStore;
        // }
        $product->price = $request->get('price');
        $product->gender = $request->get('gender');
        $product->category = $request->get('category');
        $product->category = $request->get('subcategory');
        $product->quantity = $request->get('quantity');
        $product->description = $request->get('description');
        $product->size = $request->get('size');
        // // Сохраняем имя файла в базе данных
        // $product->image = $fileNameToStore;
        $product->price = $request->get('price');
        $product->category = $request->get('category');
        $product->rent_or_buy = $request->get('rent_or_buy');
        $product->quantity = $request->get('quantity');
        $product->description = $request->get('description');
        $product->size = $request->get('size');
        $product->save();

        if (!Auth::check()) {
            return redirect()->route('login');
        }
        if (Auth::user()->role == '2')
            return redirect()->back()->with('success', 'Товар добавлен.');
        else
            return view('admin.none-admin');
    }



    public function editProduct($id)
    {
        $product = Product::findOrFail($id);
        $category = DB::table('categories')->get();
        $subcategories = DB::table('subcategories')->get();

        if (!Auth::check()) {
            return redirect()->route('login');
        }
        if (Auth::user()->role == '2')
            return view('admin.editProduct', compact('product', 'category', 'subcategories'));
        else
            return view('admin.none-admin');
    }

    public function updateProduct(Request $request, $id)
    {
        // $file= $request->file('image');
        // $filename = time().$file->getClientOriginalName();
        // $file -> move('img', $filename);
        $product = Product::find($id);

        if ($product) {
            // $product->image = $filename;
            $product->name = $request->get('name');
            $product->description = $request->get('description');
            $product->price = $request->get('price');

            if ($request->hasFile('image')) {
                $file = $request->file('image');
                $filename = time() . $file->getClientOriginalName();
                $file->move('img', $filename);
                $product->image = $filename;
            }

            $product->category = $request->get('category');
            $product->gender = $request->get('gender');
            $product->rent_or_buy = $request->get('rent_or_buy');
            $product->quantity = $request->get('quantity');
            $product->size = $request->get('size');
            $product->save();

            return redirect()->route('admin.products');
        } else {
            return redirect()->back()->with('error', 'Товар не найден.');
        }
    }



    public function deleteProduct($id)
    {
        $product = Product::findOrFail($id);

        $product->delete();

        if (!Auth::check()) {
            return redirect()->route('login');
        }
        if (Auth::user()->role == '2')
            return redirect()->back()->with('success', 'Товар удален.');
        else
            return view('admin.none-admin');
    }

    public function categories()
    {
        $categories = Category::all();
        $subcategories = Subcategory::with('category')->get();

        if (!Auth::check()) {
            return redirect()->route('login');
        }
        if (Auth::user()->role == '2')
            return view('admin.categories', compact('categories', 'subcategories'));
        else
            return view('admin.none-admin');
    }

    public function addCategory(Request $request)
    {
        $category = new Category;

        $category->name_category = $request->get('name');
        $category->save();

        if (!Auth::check()) {
            return redirect()->route('login');
        }
        if (Auth::user()->role == '2')
            return redirect()->back()->with('success', 'Категория добавлена.');
        else
            return view('admin.none-admin');
    }

    public function addSubcategory(Request $request)
    {
        $subcategory = new Subcategory;

        $categoryID = $request->input('sub_cat'); // Получаем идентификатор категории
        $subcategoryName = $request->input('subcategory_name' . $categoryID); // Получаем значение поля с уникальным именем

        $subcategory->name = $subcategoryName;
        $subcategory->category_id = $categoryID;
        $subcategory->save();

        if (!Auth::check()) {
            return redirect()->route('login');
        }
        if (Auth::user()->role == '2')
            return redirect()->back()->with('success', 'Категория добавлена.');
        else
            return view('admin.none-admin');
    }

    public function deleteCategory($id)
    {
        $category  = Category::find($id);
        $category->delete();

        if (!Auth::check()) {
            return redirect()->route('login');
        }
        if (Auth::user()->role == '2')
            return redirect()->back()->with('success', 'Категория  удален.');
        else
            return view('admin.none-admin');
    }

    public function deleteSubcategory($id)
    {
        $subcategory  = Subcategory::find($id);
        $subcategory->delete();

        if (!Auth::check()) {
            return redirect()->route('login');
        }
        if (Auth::user()->role == '2')
            return redirect()->back()->with('success', 'Категория  удален.');
        else
            return view('admin.none-admin');
    }

    public function editCategory($id)
    {
        $category = Category::findOrFail($id);

        if (!Auth::check()) {
            return redirect()->route('login');
        }
        if (Auth::user()->role == '2')
            return view('admin.edit-category', compact('category'));
        else
            return view('admin.none-admin');
    }

    // метод обновления категории в базе данных
    public function updateCategory(Request $request, $id)
    {
        $category = Category::find($id);

        if ($category) {
            $categoryName = $request->input('category_name' . $category->id);

            $category->name_category = $categoryName;
            $category->save();
            return redirect()->route('admin.category');
        } else {
            return redirect()->back()->with('error', 'Категория не найдена.');
        }

        if (!Auth::check()) {
            return redirect()->route('login');
        }
        if (Auth::user()->role == '2')
            return view('admin.edit-category', compact('category'));
        else
            return view('admin.none-admin');
    }

    public function updateSubcategory(Request $request, $id)
    {
        $subcategory = Subcategory::find($id);

        if ($subcategory) {
            $subcategoryName = $request->input('edit_subcategory_name' . $subcategory->id); // Получаем значение поля с уникальным именем

            $subcategory->name = $subcategoryName;
            $subcategory->save();

            return redirect()->route('admin.category');
        } else {
            return redirect()->back()->with('error', 'Подкатегория не найдена.');
        }

        if (!Auth::check()) {
            return redirect()->route('login');
        }
        if (Auth::user()->role == '2') {
            return view('admin.edit-category', compact('category'));
        } else {
            return view('admin.none-admin');
        }
    }

    public function users()
    {
        $users = User::all();

        if (!Auth::check()) {
            return redirect()->route('login');
        }
        if (Auth::user()->role == '2')
            return view('admin.users', compact('users'));
        else
            return view('admin.none-admin');
    }

    public function updateUser(Request $request, $id)
    {
        $user = User::find($id);
        $user->role = $request->get('role');
        $user->save();

        return redirect()->route('admin.users');
    }

    public function deleteUser($id)
    {
        $user = User::findOrFail($id);
        $user->delete();

        if (!Auth::check()) {
            return redirect()->route('login');
        }
        if (Auth::user()->role == '2')
            return redirect('/admin/users')->with('success');
        else
            return view('admin.none-admin');
    }

    public function showBooking(Request $request)
    {
        $status = $request->get('status');
        $user = Auth::user();

        $bookings = Booking::query();

        if ($status) {
            $bookings->where('status', $status);
        }

        $bookings = $bookings->orderBy('created_at', 'desc')->paginate(100000000);

        if (!Auth::check()) {
            return redirect()->route('login');
        }
        if (Auth::user()->role == '2')
            return view('admin.booking', compact('bookings', 'status', 'user'));
        else
            return view('admin.none-admin');
    }

    public function cancelBooking($id)
    {
        $booking = Booking::findOrFail($id);

        $booking->status = 'Отменен';
        $booking->save();

        if (!Auth::check()) {
            return redirect()->route('login');
        }
        if (Auth::user()->role == '2')
            return redirect()->back()->with('success', 'Бронирование отменено.');
        else
            return view('admin.none-admin');
    }

    public function confirmBooking($id)
    {
        $booking = Booking::findOrFail($id);

        $booking->status = 'Подтвержден';
        $booking->save();

        if (!Auth::check()) {
            return redirect()->route('login');
        }
        if (Auth::user()->role == '2')
            return redirect()->back()->with('success', 'Бронирование подтверждено.');
        else
            return view('admin.none-admin');
    }
}
