<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;
use App\Models\Category;
use App\Models\Subcategory;

class CatalogController extends Controller
{
    public function catalog(Request $request)
    {
        // Получаем параметры сортировки и фильтрации
        $sortBy = $request->input('sort_by', 'created_at');
        $category = $request->input('category', '');
        $rentOrBuy = $request->input('rent_or_buy', '');
        $subcategory = $request->input('subcategory', '');
        $gender = $request->input('gender', '');

        // Получаем список товаров с учетом параметров сортировки и фильтрации
        $products = Product::where('quantity', '>=', 0)
            ->when($category, function ($query, $category) {
                return $query->where('category', $category);
            })
            ->when($rentOrBuy, function ($query, $rentOrBuy) {
                return $query->where('rent_or_buy', $rentOrBuy);
            })
            ->when($gender, function ($query, $gender) {
                return $query->where('gender', $gender);
            })
            ->when($subcategory, function ($query, $subcategory) {
                return $query->where('subcategory', $subcategory);
            })
            ->orderBy($sortBy, $request->input('sort_direction', 'asc'))->get();

        $categories = Category::all();
        $subcategories = Subcategory::all();
        return view('catalog', compact('products', 'category', 'categories', 'sortBy', 'rentOrBuy', 'gender', 'subcategories', 'subcategory'));
    }

    public function getCategoriesByGender($gender)
    {
        $categories = Category::where('gender', $gender)->get();
        return response()->json($categories);
    }

}
